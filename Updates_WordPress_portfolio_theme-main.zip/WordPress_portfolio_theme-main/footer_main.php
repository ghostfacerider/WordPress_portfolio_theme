 <script src="https://cdnjs.cloudflare.com/ajax/libs/typed.js/2.0.12/typed.min.js" referrerpolicy="no-referrer"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <!--========== SCROLL UP ==========-->
        <!--========== MIXITUP FILTER ==========-->
        <script src="js/mixitup.min.js"></script>
        <!--========== SWIPER JS ==========-->
        <script src="js/swiper-bundle.min.js"></script>
        <!--========== MAIN JS ==========-->
        <script src="js/main.js"></script>
</body>

</html>